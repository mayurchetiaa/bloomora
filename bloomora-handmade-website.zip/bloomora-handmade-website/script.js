// CUSTOMIZE THIS FILE: change your brand name, Instagram username and products below.
const BRAND_NAME = "Bloomora";
const INSTAGRAM_USERNAME = "bloom.ora26"; // without the @

const products = [
  { name: "Pressed Flower Charm", description: "A tiny piece of nature, kept close to you.", image: "", emoji: "🌸", color: "pink" },
  { name: "Daisy Daydream", description: "A cheerful little daisy for everyday joy.", image: "", emoji: "🌼", color: "yellow" },
  { name: "Blooming Garden", description: "A colorful floral creation, made by hand.", image: "", emoji: "🌷", color: "green" },
  { name: "Pastel Petals", description: "Soft colors and sweet handmade details.", image: "", emoji: "🌺", color: "lilac" },
  { name: "Ocean Flower", description: "A little pop of color inspired by nature.", image: "", emoji: "🪻", color: "blue" },
  { name: "Peach Blossom", description: "A delicate handmade gift for someone special.", image: "", emoji: "🌹", color: "peach" }
];

const instagramUrl = `https://www.instagram.com/${INSTAGRAM_USERNAME}/`;
document.querySelectorAll("[data-brand]").forEach(el => el.textContent = BRAND_NAME);
document.querySelectorAll("[data-handle]").forEach(el => el.textContent = `@${INSTAGRAM_USERNAME}`);
document.querySelectorAll(".instagram-link").forEach(el => el.href = instagramUrl);

const grid = document.getElementById("product-grid");
products.forEach(product => {
  const card = document.createElement("article");
  card.className = "product-card";
  const imageArea = product.image
    ? `<div class="product-image"><img src="${product.image}" alt="${product.name}"></div>`
    : `<div class="product-image ${product.color}"><span aria-hidden="true">${product.emoji}</span></div>`;
  card.innerHTML = `${imageArea}
    <div class="product-info">
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <a class="dm-link" href="${instagramUrl}" target="_blank" rel="noopener">DM US TO KNOW THE PRICE ↗</a>
    </div>`;
  grid.appendChild(card);
});

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));
