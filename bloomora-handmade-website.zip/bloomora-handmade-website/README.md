# Handmade keychain boutique website

A responsive, colorful starter website for a handmade keychain / pressed-flower brand.

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in a browser.

## Personalize your brand
Open `script.js` and edit:
- `BRAND_NAME` — currently set to Bloomora.
- `INSTAGRAM_USERNAME` — currently set to bloom.ora26.
- `products` — product names, descriptions, emoji placeholders, colors and image paths.

## Add your product photos
1. Create an `images` folder beside `index.html`.
2. Put your product photos inside it, for example `daisy-keychain.jpg`.
3. In the matching product object in `script.js`, set `image: "images/daisy-keychain.jpg"`.
4. Replace the emoji placeholder if you like; when `image` is filled in, the photo is shown instead.

Add another product by copying one object inside the `products` array and changing its details. Keep commas between objects.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account at https://github.com/.
2. Create a new public repository, for example `handmade-keychain-store`.
3. Upload `index.html`, `style.css`, `script.js`, `README.md` and your `images` folder.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then save.
7. GitHub will show your public website URL on the Pages settings screen.

## Notes
- This starter does not take payments or store orders.
- Product buttons open your Instagram profile so customers can DM you.
- Replace all sample product details and placeholder branding before publishing.
